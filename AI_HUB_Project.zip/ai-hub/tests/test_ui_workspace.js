// Run with: node tests/test_ui_workspace.js
// Exercise the shipped workspace and Markdown renderer without a network or browser.
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const vm = require("node:vm");

const staticPath = path.join(__dirname, "../app/static");
const html = fs.readFileSync(path.join(staticPath, "workspace.html"), "utf8");
const script = fs.readFileSync(path.join(staticPath, "workspace.js"), "utf8");
const markdown = fs.readFileSync(path.join(staticPath, "workspace-markdown.js"), "utf8");
const A = "geopolitical-morning", B = "education-observatory", PREFIX = "/v1/public/workspace";
const SOURCE_ID = "src_" + "a".repeat(16);
const clone = value => JSON.parse(JSON.stringify(value));
const conversationId = number => "conv_" + number.toString(16).padStart(32, "0");

class Element {
  constructor(tag = "div") {
    this.tagName = tag.toUpperCase(); this.nodeType = 1; this.childNodes = [];
    this.className = ""; this.value = ""; this.attributes = {}; this.events = {};
    this.dataset = {}; this.style = {}; this.disabled = false; this.hidden = false;
    this.scrollTop = 0; this.scrollHeight = 0; this.clientHeight = 100;
    this.classList = {
      add: (...names) => { this.className = [...new Set([...this.className.split(/\s+/).filter(Boolean), ...names])].join(" "); },
      remove: (...names) => { this.className = this.className.split(/\s+/).filter(name => !names.includes(name)).join(" "); },
      contains: name => this.className.split(/\s+/).includes(name),
      toggle: (name, force) => { const add = force === undefined ? !this.classList.contains(name) : force;
        this.classList[add ? "add" : "remove"](name); return add; }
    };
  }
  get children() { return this.childNodes.filter(node => node.nodeType === 1); }
  get textContent() { return this.childNodes.map(node => node.textContent).join(""); }
  set textContent(value) { this.childNodes = [{nodeType: 3, textContent: String(value)}]; }
  set innerHTML(_) { throw new Error("Untrusted report or chat content must not be inserted as HTML."); }
  append(...nodes) { for (const node of nodes) { const child = typeof node === "string" ? {nodeType: 3, textContent: node} : node;
    child.parentNode = this; this.childNodes.push(child); } }
  replaceChildren(...nodes) { this.childNodes = []; this.append(...nodes); }
  setAttribute(name, value) {
    this.attributes[name] = String(value);
    if (name === "class") this.className = String(value);
    if (["id", "dir", "lang", "placeholder", "value", "href", "type"].includes(name)) this[name] = String(value);
    if (["disabled", "hidden", "open"].includes(name)) this[name] = true;
    if (name.startsWith("data-")) this.dataset[name.slice(5).replace(/-([a-z])/g, (_, char) => char.toUpperCase())] = String(value);
  }
  getAttribute(name) { return this.attributes[name] ?? null; }
  removeAttribute(name) { delete this.attributes[name]; if (["hidden", "disabled", "open"].includes(name)) this[name] = false; else delete this[name]; }
  querySelectorAll(selector) {
    if (/^\[[\w-]+\]$/.test(selector)) return descendants(this, el => el.getAttribute(selector.slice(1, -1)) !== null);
    if (selector.startsWith(".")) return descendants(this, el => el.classList.contains(selector.slice(1)));
    if (selector.startsWith("#")) return descendants(this, el => el.id === selector.slice(1));
    return descendants(this, el => el.tagName === selector.toUpperCase());
  }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
  addEventListener(type, listener) { (this.events[type] ||= []).push(listener); }
  async emit(type, details = {}) {
    let prevented = false;
    const event = {target: this, key: "", shiftKey: false, isComposing: false,
      preventDefault() { prevented = true; }, ...details};
    for (const listener of this.events[type] || []) await listener(event);
    return prevented;
  }
  async click() { if (this.disabled) return; return this.emit("click"); }
  requestSubmit() { return this.emit("submit"); }
  focus() { this.ownerDocument.activeElement = this; }
  setSelectionRange(start, end) { this.selectionStart = start; this.selectionEnd = end; }
  scrollIntoView() {}
}

function descendants(root, predicate) {
  return root.children.flatMap(child => [...(predicate(child) ? [child] : []), ...descendants(child, predicate)]);
}
const byClass = (root, name) => descendants(root, element => element.classList.contains(name));
const byTag = (root, tag) => descendants(root, element => element.tagName === tag.toUpperCase());
const profiles = [A, B].map((id, i) => ({id, agent_id: id, name: i ? "Education observer" : "Geopolitical briefing",
  name_en: i ? "Education observer" : "Geopolitical briefing", name_ar: i ? "مرصد التعليم" : "الإحاطة الجيوسياسية",
  enabled: true, kind: "briefing", default_topic_en: i ? "Global education developments" : "Consequential global geopolitics",
  default_topic_ar: i ? "مستجدات التعليم العالمية" : "التطورات الجيوسياسية العالمية",
  views: [{id: "evidence", title_en: "News", title_ar: "الأخبار"}, {id: "pack", title_en: "Briefing Pack", title_ar: "ملف الإحاطة"}]}));

function job(agent = A, sequence = 1, overrides = {}) {
  return {job_id: `job_${agent}_${sequence}`, agent_id: agent, generation_seq: sequence, topic: profiles.find(p => p.id === agent).default_topic_en,
    language: "en", status: "queued", stage: "queued", research_window: {start: "2026-10-20T00:00:00Z", end: "2026-10-20T12:00:00Z"}, ...overrides};
}
function report(agent = A, sequence = 1, overrides = {}) {
  const current = job(agent, sequence), reportId = `rpt_${agent}_${sequence}`;
  return {report_id: reportId, agent_id: agent, job_id: current.job_id, generation_seq: sequence, topic: current.topic,
    language: "en", research_cutoff: current.research_window.end, research_window: current.research_window,
    pdf: {status: "ready"}, status: "ready", result: {schema_version: 2, agent_id: agent, language: "en", kind: "briefing",
      title: `Saved ${agent} generation ${sequence}`, research_window: current.research_window,
      items: [{id: "n1", headline: `Verified ${agent} headline ${sequence}`, publisher: "Fixture Publisher",
        published_at: "2026-10-20T11:00:00Z", summary: "A synthetic verified finding.", why_it_matters: "Evidence-based implications.",
        url: "https://publisher.example/synthetic", source_ids: [SOURCE_ID]}],
      sections: [{id: "executive_summary", title: "Executive summary", body: "**Synthetic assessment.** [Evidence](https://publisher.example/synthetic)", source_ids: [SOURCE_ID]}],
      sources: [{id: SOURCE_ID, title: "Original synthetic evidence", publisher: "Fixture Publisher", role: "fresh",
        url: "https://publisher.example/synthetic", published_at: "2026-10-20T11:00:00Z"}], limitations: []}, ...overrides};
}

function harness(options = {}) {
  const elements = new Map(), tree = new Element("document"), stack = [tree];
  const voidTags = new Set(["META", "LINK", "INPUT", "BR", "HR", "IMG"]);
  for (const match of html.matchAll(/<\/?([a-zA-Z][a-zA-Z0-9-]*)\b([^>]*)>|([^<]+)/g)) {
    if (match[3] !== undefined) { stack.at(-1).append(match[3]); continue; }
    if (match[0].startsWith("</")) { if (stack.length > 1) stack.pop(); continue; }
    const element = new Element(match[1]);
    for (const attribute of match[2].matchAll(/([a-zA-Z_][\w-]*)(?:="([^"]*)")?/g)) element.setAttribute(attribute[1], attribute[2] ?? "");
    if (element.id) elements.set(element.id, element);
    stack.at(-1).append(element); if (!voidTags.has(element.tagName)) stack.push(element);
  }
  const body = byTag(tree, "body")[0], requests = [], timers = new Map();
  const storage = options.storage || new Map([["aihub.language", options.language || "en"]]);
  const session = options.session || new Map();
  const storageApi = map => ({getItem: key => map.get(key) ?? null, setItem: (key, value) => map.set(key, String(value)), removeItem: key => map.delete(key)});
  const documentEvents = new Map();
  const document = {body, documentElement: byTag(tree, "html")[0], activeElement: body, title: "", hidden: false,
    addEventListener: (name, handler) => documentEvents.set(name, handler),
    getElementById: id => elements.get(id), createElement: tag => {const el = new Element(tag); el.ownerDocument = document; return el;},
    createTextNode: text => ({nodeType: 3, textContent: String(text)}), querySelectorAll: selector => tree.querySelectorAll(selector)};
  for (const element of descendants(tree, () => true)) element.ownerDocument = document;
  const server = {jobs: new Map(), reports: new Map(), snapshots: new Map(), sequences: new Map(), feeds: new Map(options.feeds || []), conversations: 0};
  let uuid = 0, timerId = 0;
  const respond = (data, status = 200) => ({ok: status >= 200 && status < 300, status, json: async () => clone(data)});
  function defaultResponse(url, request) {
    const method = request.method || "GET", parsed = new URL(url, "https://ai-hub.test");
    const pathname = parsed.pathname, input = request.body ? JSON.parse(request.body) : {};
    if (pathname === "/v1/public/bootstrap") return respond({});
    if (pathname === PREFIX + "/config") return respond({agents: options.profiles || profiles, agent_count: (options.profiles || profiles).length, news_enabled_agents: options.newsAgents || []});
    const newsPath = pathname.match(/^\/v1\/public\/workspace\/agents\/([^/]+)\/news(?:\/refresh)?$/);
    if (newsPath) return respond(server.feeds.get(decodeURIComponent(newsPath[1]) + ":" + (input.language || parsed.searchParams.get("language"))) || {status: "empty", items: [], last_successful_refresh_at: new Date(now).toISOString()});
    const generate = pathname.match(/^\/v1\/public\/workspace\/agents\/([^/]+)\/reports$/);
    if (generate && method === "POST") {
      const agent = decodeURIComponent(generate[1]), sequence = (server.sequences.get(agent) || 0) + 1;
      server.sequences.set(agent, sequence);
      const queued = job(agent, sequence, {topic: input.topic, language: input.language});
      server.jobs.set(queued.job_id, {job: queued, report: null});
      return respond({job: queued, last_successful_report: null, joined_existing: false}, 202);
    }
    const agentPath = pathname.match(/^\/v1\/public\/workspace\/agents\/([^/]+)$/);
    if (agentPath) return respond(server.snapshots.get(decodeURIComponent(agentPath[1])) || {last_successful_report: null, active_job: null});
    const jobPath = pathname.match(/^\/v1\/public\/workspace\/jobs\/([^/]+)$/);
    if (jobPath) return respond(server.jobs.get(decodeURIComponent(jobPath[1])) || {detail: {code: "job_not_found"}}, server.jobs.has(decodeURIComponent(jobPath[1])) ? 200 : 404);
    if (pathname === PREFIX + "/reports") return respond({reports: [...server.reports.values()].filter(r => !parsed.searchParams.get("agent_id") || r.agent_id === parsed.searchParams.get("agent_id"))});
    const reportPath = pathname.match(/^\/v1\/public\/workspace\/reports\/([^/]+)$/);
    if (reportPath) return respond(server.reports.get(decodeURIComponent(reportPath[1])) || {detail: {code: "report_not_found"}}, server.reports.has(decodeURIComponent(reportPath[1])) ? 200 : 404);
    if (pathname === "/v1/public/chat/conversations") {
      if (method === "POST") return respond({conversation_id: conversationId(++server.conversations)}, 201);
      return respond({conversations: []});
    }
    if (/^\/v1\/public\/chat\/conversations\/[^/]+$/.test(pathname)) return respond({messages: [], pagination: {has_more: false}});
    if (/^\/v1\/public\/workspace\/chat\/conversations\/[^/]+\/messages$/.test(pathname)) return respond(answer(input));
    throw new Error("Unexpected fixture route: " + method + " " + url);
  }
  let now = options.now ?? Date.now();
  class ClockDate extends Date { constructor(...args) { super(...(args.length ? args : [now])); } static now() { return now; } }
  const context = {document, URL, AbortController, console, Date: ClockDate,
    localStorage: storageApi(storage), sessionStorage: storageApi(session), crypto: {randomUUID: () => "workspace-fixture-" + (++uuid)},
    setTimeout: (callback, ms) => { const id = ++timerId; timers.set(id, {callback, ms}); return id; },
    clearTimeout: id => timers.delete(id),
    fetch: async (url, request) => { requests.push({url, options: request});
      const custom = options.fetch ? await options.fetch(url, request, respond, server) : undefined;
      return custom === undefined ? defaultResponse(url, request) : custom; }
  };
  context.window = context;
  const exposed = script.replace(/\n  initialize\(\);\n\}\)\(typeof window!=="undefined"\?window:globalThis\);\s*$/,
    "\n  global.AIHubWorkspaceTest={initialize,openAgent,generateReport,acceptJob,acceptReport,pollJob,openSaved,loadHistory,setLanguage,request,state,chatState,sendChat,current,loadNews,newsState,selected:()=>selectedId};\n})(typeof window!==\"undefined\"?window:globalThis);");
  assert.notEqual(exposed, script, "The harness must exercise the actual initialization and shipped workflow functions.");
  vm.createContext(context); vm.runInContext(markdown, context); vm.runInContext(exposed, context);
  async function settle() { for (let i = 0; i < 60; i++) await Promise.resolve(); }
  async function advance(ms = 1800) { const pending = [...timers].filter(([, entry]) => entry.ms <= ms);
    for (const [id, entry] of pending) { if (timers.delete(id)) entry.callback(); } await settle(); }
  const generations = () => requests.filter(request => request.options.method === "POST" && /\/agents\/[^/]+\/reports$/.test(request.url));
  const messages = () => requests.filter(request => request.options.method === "POST" && /\/messages$/.test(request.url));
  const newsRequests = () => requests.filter(request => /\/news(?:\/refresh|\?language=)/.test(request.url));
  const visibility = async hidden => {document.hidden = hidden; documentEvents.get("visibilitychange")?.(); await settle();};
  return {...context.AIHubWorkspaceTest, elements, body, requests, storage, session, server, settle, advance, generations, messages, newsRequests, visibility, setNow: value => {now = value;}};
}

function answer(input = {}, overrides = {}) {
  return {conversation_id: conversationId(1), user_message: {id: "message_user_1", role: "user", content: input.message || "Question"},
    message: {id: "message_answer_1", role: "assistant", content: "**Saved evidence answer.** [Source](https://publisher.example/synthetic)"},
    context: {report_id: input.report_id, report_ids: input.report_id ? [input.report_id] : [], agent_ids: input.agent_id ? [input.agent_id] : []}, ...overrides};
}
async function start(options = {}) { const ui = harness(options); await ui.initialize(); await ui.settle(); return ui; }
async function topicKey(ui, details = {}) { const prevented = await ui.elements.get("topic-input").emit("keydown", {key: "Enter", ...details}); await ui.settle(); return prevented; }
async function typeChat(ui, text) { const input = ui.elements.get("discussion-panel").querySelector("textarea");
  input.value = text; await input.emit("input"); return input; }
function seed(ui, agent = A, sequence = 1) { const saved = report(agent, sequence); ui.server.reports.set(saved.report_id, saved);
  ui.server.snapshots.set(agent, {last_successful_report: saved, active_job: null}); ui.server.sequences.set(agent, sequence); return saved; }

const NEWS_NOW = Date.parse("2026-10-20T12:00:00Z");
function newsItem(index = 1, overrides = {}) {return {article_id: "article_" + index, headline: "Live article " + index,
  summary: "Verified source metadata.", publisher: "Publisher " + (index % 3), url: "https://publisher.example/live/" + index,
  published_at: new Date(NEWS_NOW - index * 1000).toISOString(), original_language: "en", display_language: "en", ...overrides};}
function newsFeed(overrides = {}) {return {status: "fresh", items: [newsItem()], stale: false, partial: false,
  last_successful_refresh_at: "2026-10-20T11:59:00Z", next_refresh_at: "2026-10-20T12:15:00Z", pagination: {raw_count: 1}, ...overrides};}

test("dashboard loads its live feed independently of report generation and shows honest refresh metadata", async () => {
  const ui = await start({now: NEWS_NOW, newsAgents: [A], feeds: [[A + ":en", newsFeed()]]});
  const home = ui.elements.get("home-news-content");
  assert.equal(ui.elements.get("home-news").hidden, false);
  assert.match(home.textContent, /Fresh.*Last successful refresh/);
  assert.match(home.textContent, /Next automatic refresh/);
  assert.match(home.textContent, /1 articles from the last 12 hours.*1 provider records fetched/);
  assert.equal(ui.newsRequests().length, 1); assert.equal(ui.newsRequests()[0].options.method, "GET");
  assert.equal(ui.generations().length, 0); assert.equal(ui.messages().length, 0);
  assert.equal(byTag(home, "time")[0].getAttribute("datetime"), newsItem().published_at);
  assert.equal(byTag(home, "a").find(a => /Open original source/.test(a.textContent)).href, newsItem().url);
});

test("the live news tab displays up to100 fresh unique articles and rejects old, future, undated and unsafe items", async () => {
  const items = Array.from({length: 104}, (_, i) => newsItem(i + 1));
  items.unshift(newsItem(1), newsItem(201, {published_at: "2026-10-19T23:59:59Z"}), newsItem(202, {published_at: "2026-10-20T12:00:01Z"}),
    newsItem(203, {published_at: "2026-10-20"}), newsItem(204, {url: "javascript:alert(1)"}));
  const ui = await start({now: NEWS_NOW, newsAgents: [A], feeds: [[A + ":en", newsFeed({items, pagination: {raw_count: items.length}})]]});
  assert.equal(byClass(ui.elements.get("home-news-content"), "live-news-item").length, 6);
  await byClass(ui.elements.get("home-news-content"), "news-view-all")[0].click(); await ui.settle();
  const content = ui.elements.get("report-content"), shown = byClass(content, "live-news-item");
  assert.equal(shown.length, 100); assert.match(content.textContent, /100 articles from the last 12 hours/);
  assert.doesNotMatch(content.textContent, /Live article 20[1-4]/);
  assert.equal(ui.generations().length, 0, "Viewing the full news feed must not start a report/model request.");
});

test("manual refresh preserves cached articles during loading and provider failure is distinct from empty", async () => {
  let release;
  const ui = await start({now: NEWS_NOW, newsAgents: [A], feeds: [[A + ":en", newsFeed()]], fetch: (url, request, respond) => {
    if (url.endsWith("/news/refresh")) return new Promise(resolve => { release = () => resolve(respond({detail: {code: "newsdata_timeout", retryable: true, reference: "news_timeout_1"}}, 504)); });
  }});
  const first = byClass(ui.elements.get("home-news-content"), "news-refresh")[0].click(); await ui.settle();
  let home = ui.elements.get("home-news-content");
  assert.match(home.textContent, /Refreshing news/); assert.match(home.textContent, /Live article 1/);
  assert.equal(byClass(home, "news-refresh")[0].disabled, true);
  await byClass(home, "news-refresh")[0].click();
  assert.equal(ui.newsRequests().filter(r => r.options.method === "POST").length, 1);
  release(); await first; await ui.settle(); home = ui.elements.get("home-news-content");
  assert.match(home.textContent, /News refresh failed.*timed out/);
  assert.match(home.textContent, /Live article 1/); assert.doesNotMatch(home.textContent, /The source check completed without/);
  assert.match(home.textContent, /news_timeout_1/); assert.equal(ui.generations().length, 0);
});

test("provider-error payload keeps the last successful refresh and stale articles expire without becoming fresh", async () => {
  const data = newsFeed({status: "provider_error", stale: true, partial: true,
    items: [newsItem(), newsItem(10, {published_at: "2026-10-19T23:00:00Z"})],
    error: {code: "newsdata_rate_limited", retryable: true, retry_after_seconds: 300, reference: "news_rate_1"}});
  const ui = await start({now: NEWS_NOW, newsAgents: [A], feeds: [[A + ":en", data]]});
  const home = ui.elements.get("home-news-content");
  assert.match(home.textContent, /News refresh failed.*request limit/);
  assert.match(home.textContent, /Retry after 300 seconds/); assert.match(home.textContent, /last successful refresh is stale/);
  assert.match(home.textContent, /Coverage is partial/); assert.match(home.textContent, /1 articles from the last 12 hours/);
  assert.doesNotMatch(home.textContent, /Live article 10/);
  assert.equal(byClass(home, "news-feed-status")[0].classList.contains("fresh"), false);
});

test("loading feed polls saved status and a successful empty response is labelled separately", async () => {
  const ui = await start({now: NEWS_NOW, newsAgents: [A], feeds: [[A + ":en", newsFeed({status: "loading", items: [], last_successful_refresh_at: null})]]});
  assert.match(ui.elements.get("home-news-content").textContent, /Refreshing news.*No successful refresh yet/);
  ui.server.feeds.set(A + ":en", newsFeed({status: "empty", items: [], pagination: {raw_count: 12}}));
  await ui.advance(2000);
  const home = ui.elements.get("home-news-content");
  assert.match(home.textContent, /No qualifying articles/); assert.match(home.textContent, /The source check completed without articles/);
  assert.match(home.textContent, /12 provider records fetched/);
  assert.equal(ui.newsRequests().length, 2); assert.equal(ui.newsRequests().some(r => r.options.method === "POST"), false);
  assert.equal(ui.generations().length, 0);
});

test("automatic feed refresh waits for its due time and pauses when the page is hidden or another view is open", async () => {
  const ui = await start({now: NEWS_NOW, newsAgents: [A], feeds: [[A + ":en", newsFeed()]]});
  await ui.advance(10000); assert.equal(ui.newsRequests().length, 1);
  await ui.visibility(true); await ui.advance(900000); assert.equal(ui.newsRequests().length, 1);
  ui.setNow(NEWS_NOW + 15 * 60000); await ui.visibility(false); await ui.advance(60000);
  assert.equal(ui.newsRequests().length, 2);
  await ui.elements.get("nav-chat").click(); await ui.settle(); await ui.advance(900000);
  assert.equal(ui.newsRequests().length, 2); assert.equal(ui.generations().length, 0);
});

test("Arabic and English feeds keep their own data and identify missing translation", async () => {
  const ui = await start({now: NEWS_NOW, newsAgents: [A], feeds: [[A + ":en", newsFeed()], [A + ":ar", newsFeed({items: [
    newsItem(1, {headline_ar: "خبر عربي موثّق", summary_ar: "ملخص الخبر بالعربية", display_language: "ar"}), newsItem(2)
  ]})]]});
  await ui.elements.get("language-ar").click(); await ui.settle();
  const home = ui.elements.get("home-news-content");
  assert.equal(home.dir, "rtl"); assert.match(home.textContent, /خبر عربي موثّق/); assert.match(home.textContent, /آخر تحديث ناجح/);
  assert.match(home.textContent, /الترجمة إلى لغة الواجهة غير متاحة/);
  assert.equal(ui.newsRequests().length, 2); assert.match(ui.newsRequests()[1].url, /language=ar$/);
  await ui.elements.get("language-en").click(); await ui.settle();
  assert.match(home.textContent, /Live article 1/); assert.doesNotMatch(home.textContent, /خبر عربي موثّق/);
  assert.equal(ui.generations().length, 0); assert.equal(ui.messages().length, 0);
});

test("the observed twelve-hour provider delay is an honest empty result without inferring the account plan", async () => {
  const delayed = newsFeed({status: "empty", items: [], pagination: {raw_count: 10}, limitation_codes: ["provider_delay", "provider_plan_unverified"],
    suspected_provider_delay: true, observed_latest_provider_publication_at: "2026-10-19T23:59:50Z", provider_age_seconds: 43210,
    provider_plan: {configured_plan: "unknown", plan_verified: false}});
  const ui = await start({now: NEWS_NOW, newsAgents: [A], feeds: [[A + ":en", delayed], [A + ":ar", delayed]]});
  let home = ui.elements.get("home-news-content");
  assert.match(home.textContent, /No qualifying articles.*latest available articles are outside the last 12-hour window/);
  assert.match(home.textContent, /may have a 12-hour delay.*Latest publication returned by the source.*03:59/);
  assert.match(home.textContent, /10 provider records fetched/);
  assert.doesNotMatch(home.textContent, /confirmed free|News refresh failed|Retry report/);
  await ui.elements.get("language-ar").click(); await ui.settle(); home = ui.elements.get("home-news-content");
  assert.match(home.textContent, /لا أخبار مستوفية للشروط.*أحدث المقالات المتاحة من المصدر تقع خارج/);
  assert.match(home.textContent, /قد يقدم الوصول الحالي أخبارًا متأخرة/);
  assert.doesNotMatch(home.textContent, /المجانية المؤكدة|تعذر تحديث الأخبار/);
  assert.equal(ui.generations().length, 0); assert.equal(ui.messages().length, 0);
});

test("a provider cooldown disables repeated manual refresh and unlocks without an automatic report request", async () => {
  const limited = newsFeed({status: "provider_error", error: {code: "newsdata_rate_limited", retry_after_seconds: 30, retryable: true}});
  const ui = await start({now: NEWS_NOW, newsAgents: [A], feeds: [[A + ":en", limited]]});
  let refresh = byClass(ui.elements.get("home-news-content"), "news-refresh")[0];
  assert.equal(refresh.disabled, true); await refresh.click(); await ui.loadNews(A, true);
  assert.equal(ui.newsRequests().length, 1);
  ui.setNow(NEWS_NOW + 30000); await ui.advance(30000);
  refresh = byClass(ui.elements.get("home-news-content"), "news-refresh")[0]; assert.equal(refresh.disabled, false);
  assert.doesNotMatch(ui.elements.get("home-news-content").textContent, /Retry after 30 seconds/);
  ui.server.feeds.set(A + ":en", newsFeed()); await refresh.click(); await ui.settle();
  assert.equal(ui.newsRequests().filter(r => r.options.method === "POST").length, 1);
  assert.equal(ui.generations().length, 0);
});

test("a failed loading-status poll stops the spinner and keeps previous articles with a precise retry message", async () => {
  let checks = 0;
  const ui = await start({now: NEWS_NOW, newsAgents: [A], fetch: (url, request, respond) => {
    if (url.includes("/news?")) return ++checks === 1 ? respond(newsFeed({status: "loading"})) :
      respond({detail: {code: "newsdata_connection_error", retryable: true, reference: "news_connection_1"}}, 502);
  }});
  await ui.advance(2000);
  const home = ui.elements.get("home-news-content");
  assert.match(home.textContent, /News refresh failed.*could not be reached/); assert.match(home.textContent, /Live article 1/);
  assert.doesNotMatch(home.textContent, /Refreshing news|The source check completed without/);
  assert.equal(byClass(home, "news-refresh")[0].disabled, false);
  await ui.advance(2000); assert.equal(checks, 2, "A failed status check must not continue fast polling.");
});

test("assistant total follows configuration without hardcoded removed cards", async () => {
  const nine = Array.from({length: 9}, (_, i) => ({...profiles[i % 2], id: "active-assistant-" + i}));
  const ui = await start({profiles: nine});
  assert.equal(byClass(ui.elements.get("agent-grid"), "agent-card").length, 9);
  assert.match(ui.elements.get("agent-count").textContent, /9 specialist assistants/);
});

test("the public workspace has no credential, cost, admin, or upload controls", async () => {
  assert.doesNotMatch(html, /type="(?:password|file)"|id="(?:username|password)"|\/admin|dailyCost|monthlyCost|accountOverview|usage-details|loginBox/);
  assert.match(html, /workspace\.js\?v=2\.0\.4/);
  assert.doesNotMatch(html, /src="\/static\/(?:app|public)\.js/);
  const ui = await start();
  await assert.rejects(ui.request("/v1/usage"));
  await assert.rejects(ui.request("https://external.example/v1/public/bootstrap"));
  assert.equal(ui.requests.length, 2);
  for (const request of ui.requests) {
    assert.equal(request.options.credentials, "same-origin"); assert.equal(request.options.cache, "no-store");
    assert.equal(request.options.headers.Authorization, undefined);
  }
});

test("card selection automatically queues the selected profile default exactly once", async () => {
  const ui = await start();
  const cards = byClass(ui.elements.get("agent-grid"), "agent-card");
  assert.equal(cards.length, 2); await cards[0].click(); await ui.settle();
  assert.equal(ui.generations().length, 1);
  assert.deepEqual(JSON.parse(ui.generations()[0].options.body), {topic: profiles[0].default_topic_en, language: "en"});
  assert.match(ui.generations()[0].url, new RegExp(A + "/reports$"));
  assert.equal(ui.selected(), A); assert.equal(ui.elements.get("workspace-view").hidden, false);
  assert.match(ui.elements.get("job-progress").textContent, /Queued for research/);
  assert.match(ui.elements.get("job-progress").textContent, /continues even if/);
});

test("Enter uses the topic form and Shift Enter or composition does not submit", async () => {
  const ui = await start(); await ui.openAgent(A, false); await ui.settle();
  ui.elements.get("topic-input").value = "Refined geopolitical question";
  assert.equal(await topicKey(ui, {shiftKey: true}), false);
  assert.equal(await topicKey(ui, {isComposing: true}), false);
  assert.equal(ui.generations().length, 0);
  assert.equal(await topicKey(ui), true);
  assert.equal(ui.generations().length, 1);
  assert.equal(JSON.parse(ui.generations()[0].options.body).topic, "Refined geopolitical question");
  await ui.elements.get("topic-form").requestSubmit(); await ui.settle();
  assert.equal(ui.generations().length, 1, "The active matching job must reconnect rather than create another report.");
});

test("duplicate card clicks and Enter while POST is in flight cannot issue another generation", async () => {
  let release;
  const ui = await start({fetch: (url, request, respond) => {
    if (request.method === "POST" && url.endsWith("/reports")) return new Promise(resolve => { release = () => resolve(respond({job: job()}, 202)); });
  }});
  const first = byClass(ui.elements.get("agent-grid"), "agent-card")[0].click(); await ui.settle();
  assert.equal(ui.generations().length, 1); assert.equal(ui.elements.get("generate-button").disabled, true);
  await topicKey(ui); await byClass(ui.elements.get("agent-grid"), "agent-card")[0].click(); await ui.settle();
  assert.equal(ui.generations().length, 1);
  ui.server.jobs.set(job().job_id, {job: job(), report: null}); release(); await first; await ui.settle();
  await topicKey(ui); assert.equal(ui.generations().length, 1);
});

test("an unconfirmed generation retry keeps its idempotency key and hides diagnostics", async () => {
  const ui = await start({fetch: (url, request) => {
    if (request.method === "POST" && url.endsWith("/reports")) throw new Error("PRIVATE provider key and cost diagnostic");
  }});
  await ui.openAgent(A, true); await ui.settle(); await topicKey(ui);
  assert.equal(ui.generations().length, 2);
  assert.equal(ui.generations()[0].options.headers["Idempotency-Key"], ui.generations()[1].options.headers["Idempotency-Key"]);
  assert.doesNotMatch(ui.body.textContent, /PRIVATE|provider key|cost diagnostic/);
});

for (const language of ["en", "ar"]) {
  test(`an asynchronous daily report limit explains the Dubai reset in ${language} and keeps the saved report`, async () => {
    const ui = await start({language}), saved = seed(ui);
    await ui.openAgent(A, true); await ui.settle();
    const queued = ui.current().job;
    ui.server.jobs.set(queued.job_id, {job: {...queued, status: "failed", error_code: "daily_report_limit"}, report: null});
    await ui.advance();
    const notice = ui.elements.get("report-notice").textContent;
    assert.match(notice, language === "en" ? /Today's report limit has been reached/ : /تم بلوغ حدّ التقارير لهذا اليوم/);
    assert.match(notice, /00:00/); assert.match(notice, /UTC\+04:00/);
    assert.match(notice, language === "en" ? /next midnight.*Dubai/ : /منتصف الليل التالي.*دبي/);
    assert.doesNotMatch(notice, /start a new attempt|بدء محاولة جديدة|\$|USD|50|budget|cost/i);
    assert.equal(ui.current().report.report_id, saved.report_id);
    assert.equal(ui.elements.get("pdf-download").hidden, false);
    assert.equal(ui.elements.get("job-progress").hidden, true);
    await ui.advance(); await ui.advance();
    assert.equal(ui.generations().length, 1, "A blocked terminal job must not retry research automatically.");
  });
}

test("a synchronous report-limit rejection uses the same specific reset message", async () => {
  const ui = await start({fetch: (url, request, respond) => {
    if (request.method === "POST" && url.endsWith("/reports"))
      return respond({detail: {code: "daily_report_limit", message: "PRIVATE diagnostics"}}, 429);
  }});
  const saved = seed(ui); await ui.openAgent(A, true); await ui.settle();
  assert.match(ui.elements.get("report-notice").textContent, /Today's report limit.*00:00 Dubai time/);
  assert.doesNotMatch(ui.body.textContent, /PRIVATE/);
  assert.equal(ui.current().report.report_id, saved.report_id);
});

for (const [code, english, arabic] of [
  ["daily_budget_limit", /daily allowance.*next midnight/, /الاستخدام اليومي.*منتصف الليل التالي/],
  ["monthly_budget_limit", /monthly allowance.*next month/, /الاستخدام الشهري.*الشهر التالي/]
]) {
  test(`asynchronous ${code} describes the allowance without exposing costs in either language`, async () => {
    const ui = await start(); seed(ui); await ui.openAgent(A, true); await ui.settle();
    const queued = ui.current().job;
    ui.server.jobs.set(queued.job_id, {job: {...queued, status: "failed", error_code: code,
      error_message: "PRIVATE provider balance $99.99 USD"}, report: null});
    await ui.advance();
    assert.match(ui.elements.get("report-notice").textContent, english);
    await ui.elements.get("language-ar").click();
    assert.match(ui.elements.get("report-notice").textContent, arabic);
    assert.doesNotMatch(ui.body.textContent, /PRIVATE|\$|USD|99\.99|budget|cost/i);
    assert.equal(ui.generations().length, 1);
  });
}

for (const language of ["en", "ar"]) {
  test(`reload restores the precise terminal report failure and previous snapshot in ${language}`, async () => {
    const session = new Map([["aihub.workspace.agent", A]]), saved = report(A, 1);
    const failed = job(A, 2, {status: "failed", stage: "checking_sources", error_code: "report_generation_failed",
      error: {code: "invalid_report_stage", reference: "job_progress_failure_1", stage: "checking_sources", retryable: false, message: "PRIVATE provider prose"}});
    const ui = await start({language, session, fetch: (url, request, respond) => {
      if (url === PREFIX + "/agents/" + A) return respond({last_successful_report: saved, active_job: null, last_job: failed});
    }});
    const notice = ui.elements.get("report-notice");
    assert.match(notice.textContent, language === "en" ? /service stopped while updating report progress/ : /توقفت الخدمة أثناء تحديث حالة التقرير/);
    assert.match(notice.textContent, language === "en" ? /Attempt stopped at: Checking sources/ : /توقفت المحاولة عند: التحقق من المصادر/);
    assert.match(notice.textContent, /job_progress_failure_1/); assert.doesNotMatch(ui.body.textContent, /PRIVATE/);
    assert.equal(ui.current().report.report_id, saved.report_id); assert.equal(ui.elements.get("pdf-download").hidden, false);
    const previous = byTag(notice, "button").find(b => b.textContent === (language === "en" ? "Open previous report" : "فتح التقرير السابق"));
    assert.ok(previous); await previous.click(); await ui.settle();
    assert.match(ui.elements.get("report-meta").textContent, language === "en" ? /Previous successful report/ : /التقرير الناجح السابق/);
    assert.equal(ui.current().tab, "pack"); assert.match(ui.elements.get("report-content").textContent, /Executive summary/);
    assert.equal(ui.generations().length, 0); assert.equal(ui.elements.get("job-progress").hidden, true);
  });
}

test("actual saving progress remains visible until completion and the saved result becomes ready", async () => {
  const ui = await start(); seed(ui); await ui.openAgent(A, true); await ui.settle();
  const running = ui.current().job;
  ui.server.jobs.set(running.job_id, {job: {...running, status: "running", stage: "saving"}, report: null});
  await ui.advance();
  assert.equal(byClass(ui.elements.get("job-progress"), "job-title")[0].textContent, "Saving report");
  assert.match(ui.elements.get("job-progress").textContent, /Status last checked/);
  await ui.elements.get("language-ar").click(); assert.match(ui.elements.get("job-progress").textContent, /حفظ التقرير/);
  ui.server.jobs.set(running.job_id, {job: {...running, status: "ready", stage: "ready"}, report: report(A, running.generation_seq)});
  await ui.advance();
  assert.match(ui.elements.get("job-progress").textContent, /التقرير جاهز/);
  assert.equal(ui.current().report.generation_seq, running.generation_seq); assert.equal(ui.generations().length, 1);
});

test("saved report counts and provider limitations remain separate from the current live feed", async () => {
  const ui = await start({now: NEWS_NOW, newsAgents: [A], feeds: [[A + ":en", newsFeed()]]}), saved = seed(ui);
  Object.assign(saved.result, {actual_article_count: 0, analyzed_article_count: 0, requested_article_target: 100,
    news_feed: {last_successful_refresh_at: "2026-10-20T11:00:00Z", limitation_codes: ["provider_delay"],
      observed_latest_provider_publication_at: "2026-10-19T22:59:50Z"}, freshness: {suspected_provider_delay: true}});
  await ui.openAgent(A, false); await ui.settle();
  assert.equal(ui.elements.get("tab-evidence").textContent, "Live news");
  assert.match(ui.elements.get("report-content").textContent, /Live article 1/);
  assert.doesNotMatch(ui.elements.get("report-content").textContent, /current access may have a 12-hour delay/);
  await ui.elements.get("tab-pack").click();
  const meta = ui.elements.get("report-meta");
  assert.match(meta.textContent, /0 qualifying news items.*Target: up to 100 articles.*0 articles analyzed/);
  assert.match(meta.textContent, /News snapshot used for this report.*latest available articles are outside/);
  assert.equal(ui.generations().length, 0);
});

test("a retryable terminal failure keeps its safe reference and retries only after explicit action and the cooldown", async () => {
  const ui = await start({now: NEWS_NOW}); seed(ui); await ui.openAgent(A, true); await ui.settle();
  const failed = ui.current().job, firstKey = ui.generations()[0].options.headers["Idempotency-Key"];
  ui.server.jobs.set(failed.job_id, {job: {...failed, status: "failed", error_code: "report_generation_failed", error: {
    code: "openai_timeout", reference: "job_timeout_1", stage: "searching", retryable: true, retry_after_seconds: 30, message: "PRIVATE $99 diagnostic"}}, report: null});
  await ui.advance();
  let notice = ui.elements.get("report-notice"), retry = byTag(notice, "button").find(b => b.textContent === "Retry report");
  assert.match(notice.textContent, /timed out.*Retry after 30 seconds.*job_timeout_1/);
  assert.doesNotMatch(ui.body.textContent, /PRIVATE|\$99/); assert.equal(retry.disabled, true);
  await retry.click(); await topicKey(ui); assert.equal(ui.generations().length, 1);
  ui.setNow(NEWS_NOW + 30000); await ui.advance(30000);
  notice = ui.elements.get("report-notice"); retry = byTag(notice, "button").find(b => b.textContent === "Retry report");
  assert.equal(retry.disabled, false); assert.equal(ui.generations().length, 1);
  await retry.click(); await ui.settle();
  assert.equal(ui.generations().length, 2); assert.notEqual(ui.generations()[1].options.headers["Idempotency-Key"], firstKey);
  assert.equal(ui.current().job.generation_seq, failed.generation_seq + 1);
});

test("first-attempt failure does not claim that a previous report exists and precise provider failures stay bilingual", async () => {
  for (const [code, english, arabic] of [
    ["unclassified_failure", /could not be completed/, /تعذر إكمال التقرير/],
    ["openai_auth_failed", /provider rejected this request/, /لم يقبل مزود البحث هذا الطلب/],
    ["openai_access_denied", /provider rejected this request/, /لم يقبل مزود البحث هذا الطلب/],
    ["openai_request_rejected", /provider rejected this request/, /لم يقبل مزود البحث هذا الطلب/],
    ["openai_quota_exceeded", /service allowance is exhausted/, /استُنفدت حصة الخدمة/],
    ["openai_rate_limited", /rate-limiting requests/, /يقيّد الطلبات/],
    ["openai_unavailable", /temporarily unavailable/, /غير متاح مؤقتًا/]
  ]) {
    const ui = await start(); await ui.openAgent(A, true); await ui.settle(); const failed = ui.current().job;
    ui.server.jobs.set(failed.job_id, {job: {...failed, status: "failed", error: {code, reference: "job_safe_1", retryable: false}}, report: null});
    await ui.advance(); assert.match(ui.elements.get("report-notice").textContent, english);
    assert.equal(byTag(ui.elements.get("report-notice"), "button").length, 0);
    assert.doesNotMatch(ui.elements.get("report-notice").textContent, /The previous report remains|Open previous report/);
    await ui.elements.get("language-ar").click(); assert.match(ui.elements.get("report-notice").textContent, arabic);
    assert.equal(ui.generations().length, 1);
  }
});

test("late older generation completion cannot replace a newer report or current job", async () => {
  const ui = await start(); seed(ui, A, 2); await ui.openAgent(A, false); await ui.settle();
  ui.acceptJob(A, job(A, 3));
  ui.server.jobs.set(job(A, 1).job_id, {job: job(A, 1, {status: "ready", stage: "ready"}), report: report(A, 1)});
  await ui.pollJob(A, job(A, 1).job_id);
  assert.equal(ui.current().latest.generation_seq, 2); assert.equal(ui.current().report.generation_seq, 2);
  assert.equal(ui.current().job.generation_seq, 3);
  assert.match(ui.elements.get("report-meta").textContent, /generation 2/);
  assert.doesNotMatch(ui.elements.get("report-meta").textContent, /generation 1/);
  assert.match(ui.elements.get("pdf-download").href, /_2\/pdf$/);
});

test("source and pack tabs, language changes, and saved-history navigation never generate", async () => {
  const ui = await start(); const latest = seed(ui, A, 2), old = report(A, 1); ui.server.reports.set(old.report_id, old);
  await ui.openAgent(A, false); await ui.settle();
  assert.match(ui.elements.get("report-content").textContent, /Verified geopolitical-morning headline 2/);
  await ui.elements.get("tab-pack").click();
  assert.match(ui.elements.get("report-content").textContent, /Executive summary/);
  assert.equal(byTag(ui.elements.get("report-content"), "strong")[0].textContent, "Synthetic assessment.");
  assert.ok(byClass(ui.elements.get("report-content"), "source-record").length);
  await ui.elements.get("language-ar").click();
  assert.equal(ui.elements.get("tab-pack").textContent, "ملف الإحاطة");
  assert.match(ui.elements.get("report-meta").textContent, /generation 2/);
  ui.elements.get("history-menu").open = true; await ui.elements.get("history-menu").emit("toggle"); await ui.settle();
  const history = byClass(ui.elements.get("report-history"), "history-record"); assert.equal(history.length, 2);
  await history[1].click(); await ui.settle();
  assert.equal(ui.current().report.report_id, old.report_id); assert.equal(ui.current().latest.report_id, latest.report_id);
  assert.equal(ui.current().pinned, true); assert.match(ui.elements.get("report-meta").textContent, /generation 1/);
  await ui.elements.get("tab-evidence").click();
  assert.match(ui.elements.get("report-content").textContent, /headline 1/);
  assert.equal(ui.generations().length, 0);
});

test("a delayed old-agent poll updates its own state without changing the visible agent or chat", async () => {
  let release;
  const ui = await start({fetch: (url, request, respond) => {
    if (url === PREFIX + "/jobs/" + job(A, 1).job_id) return new Promise(resolve => {
      release = () => resolve(respond({job: job(A, 1, {status: "ready", stage: "ready"}), report: report(A, 1)}));
    });
  }});
  await ui.openAgent(A, true); await ui.settle();
  seed(ui, B, 2); await ui.openAgent(B, false); await ui.settle();
  const heading = ui.elements.get("workspace-heading").textContent;
  release(); await ui.settle();
  assert.equal(ui.selected(), B); assert.equal(ui.elements.get("workspace-heading").textContent, heading);
  assert.equal(ui.current().report.agent_id, B); assert.equal(ui.state(A).report.agent_id, A);
  assert.match(ui.elements.get("report-meta").textContent, /education-observatory/);
  const input = await typeChat(ui, "Explain the education finding."); await input.emit("keydown", {key: "Enter"}); await ui.settle();
  assert.equal(JSON.parse(ui.messages()[0].options.body).agent_id, B);
  assert.equal(JSON.parse(ui.messages()[0].options.body).report_id, report(B, 2).report_id);
});

test("reload reconnects to the active job and saved snapshot without regenerating", async () => {
  const session = new Map([["aihub.workspace.agent", A]]);
  const currentJob = job(A, 2), saved = report(A, 1);
  const ui = await start({session, fetch: (url, request, respond) => {
    if (url === PREFIX + "/agents/" + A) return respond({active_job: currentJob, last_successful_report: saved});
    if (url === PREFIX + "/jobs/" + currentJob.job_id) return respond({job: currentJob, report: null});
  }});
  assert.equal(ui.selected(), A); assert.equal(ui.current().job.job_id, currentJob.job_id);
  assert.equal(ui.current().report.report_id, saved.report_id); assert.equal(ui.generations().length, 0);
  assert.match(ui.elements.get("report-meta").textContent, /generation 1/);
});

test("inline chat automatically sends the active agent and report and renders the answer without upload", async () => {
  const ui = await start(); const saved = seed(ui); await ui.openAgent(A, false); await ui.settle();
  const input = await typeChat(ui, "Why does this finding matter?");
  assert.equal(await input.emit("keydown", {key: "Enter"}), true); await ui.settle();
  assert.equal(ui.messages().length, 1);
  const message = ui.messages()[0], body = JSON.parse(message.options.body);
  assert.equal(body.agent_id, A); assert.equal(body.report_id, saved.report_id); assert.equal(body.topic, saved.topic);
  assert.equal(body.message, "Why does this finding matter?"); assert.equal(message.options.headers.Authorization, undefined);
  assert.match(ui.elements.get("discussion-panel").textContent, /Saved evidence answer/);
  assert.equal(byTag(ui.elements.get("discussion-panel"), "input").length, 0);
  assert.equal(ui.generations().length, 0);
});

test("fresh chat waits for the saved report then answers with the same request key", async () => {
  const newer = report(A, 2), freshJob = job(A, 2);
  let messageRequests = 0;
  const ui = await start({fetch: (url, request, respond) => {
    if (request.method === "POST" && url.endsWith("/messages")) {
      messageRequests++;
      if (messageRequests === 1) return respond({status: "researching", job: freshJob, agent_id: A}, 202);
      const body = JSON.parse(request.body);
      return respond(answer(body, {context: {report_id: newer.report_id, report_ids: [newer.report_id],
        agent_ids: [A], fresh_research: true, research_cutoffs: [{agent_id: A, cutoff: newer.research_cutoff}]}}));
    }
  }});
  seed(ui); ui.server.jobs.set(freshJob.job_id, {job: freshJob, report: null});
  await ui.openAgent(A, false); await ui.settle();
  const input = await typeChat(ui, "What has happened since this briefing?");
  await input.emit("keydown", {key: "Enter"}); await ui.settle();
  assert.equal(ui.messages().length, 1); assert.equal(ui.chatState(A).sending, true);
  assert.match(ui.elements.get("discussion-panel").textContent, /Researching fresh evidence/);
  await ui.elements.get("discussion-panel").querySelector("textarea").emit("keydown", {key: "Enter"}); await ui.settle();
  assert.equal(ui.messages().length, 1, "While research is in flight, repeated Enter must not issue another answer request.");
  ui.server.jobs.set(freshJob.job_id, {job: {...freshJob, status: "running", stage: "preparing_pdf"}, report: {...newer, pdf: {status: "pending"}}});
  await ui.advance();
  assert.equal(ui.messages().length, 2);
  assert.equal(ui.messages()[0].options.headers["Idempotency-Key"], ui.messages()[1].options.headers["Idempotency-Key"]);
  const original = JSON.parse(ui.messages()[0].options.body), resumed = JSON.parse(ui.messages()[1].options.body);
  assert.deepEqual(resumed, {...original, fresh_job_id: freshJob.job_id});
  assert.equal(ui.chatState(A).sending, false); assert.match(ui.elements.get("discussion-panel").textContent, /Saved evidence answer/);
  assert.equal(ui.current().report.report_id, newer.report_id); assert.equal(ui.generations().length, 0);
});

test("fresh chat preserves a failed research quota code and does not retry the blocked answer", async () => {
  const freshJob = job(A, 2);
  const ui = await start({fetch: (url, request, respond) => {
    if (request.method === "POST" && url.endsWith("/messages"))
      return respond({status: "researching", job: freshJob, agent_id: A}, 202);
  }});
  const saved = seed(ui);
  ui.server.jobs.set(freshJob.job_id, {job: freshJob, report: null});
  await ui.openAgent(A, false); await ui.settle();
  const input = await typeChat(ui, "What has happened since this briefing?");
  await input.emit("keydown", {key: "Enter"}); await ui.settle();
  ui.server.jobs.set(freshJob.job_id, {job: {...freshJob, status: "failed", error_code: "daily_report_limit"}, report: null});
  await ui.advance();
  assert.equal(ui.chatState(A).sending, false);
  assert.match(ui.elements.get("discussion-panel").textContent, /Today's report limit.*00:00 Dubai time/);
  assert.doesNotMatch(ui.elements.get("discussion-panel").textContent, /start a new attempt|Check this attempt/);
  assert.equal(ui.chatState(A).attempt, null);
  assert.equal(ui.current().report.report_id, saved.report_id);
  await ui.advance(); assert.equal(ui.messages().length, 1);
  assert.equal(ui.generations().length, 0);
});

test("saved-conversation placeholder and invalid choices never request a conversation", async () => {
  const existing = conversationId(7);
  const ui = await start({language: "ar", fetch: (url, request, respond) => {
    if (url === "/v1/public/chat/conversations?limit=50") return respond({conversations: [
      {conversation_id: existing, title: "محادثة محفوظة"},
      {conversation_id: "محادثات محفوظة", title: "Malformed saved entry"}
    ]});
  }});
  seed(ui); await ui.openAgent(A, false); await ui.settle();
  const select = byClass(ui.elements.get("discussion-panel"), "chat-history-select")[0];
  const options = byTag(select, "option"), detailRequests = () => ui.requests.filter(request => /^\/v1\/public\/chat\/conversations\//.test(request.url));
  assert.equal(options[0].getAttribute("value"), "", "An option without a value submits its translated label in a real browser.");
  assert.equal(options[0].disabled, true);
  assert.equal(options[0].textContent, "محادثات محفوظة");
  assert.equal(options.length, 2, "Malformed saved conversation IDs must not become selectable.");
  for (const value of ["", "محادثات محفوظة", conversationId(8), "../admin"]) {
    select.value = value; await select.emit("change"); await ui.settle();
  }
  assert.equal(detailRequests().length, 0);
  assert.equal(ui.chatState(A).id, null);
  select.value = existing; await select.emit("change"); await ui.settle();
  assert.equal(detailRequests().length, 1);
  assert.equal(detailRequests()[0].url, "/v1/public/chat/conversations/" + existing);
  assert.equal(ui.chatState(A).id, existing);
  assert.equal(ui.session.get("aihub.workspace.chat." + A), existing);
});

test("a previously persisted translated placeholder is cleared before restoring conversation history", async () => {
  const session = new Map([["aihub.workspace.agent", A], ["aihub.workspace.chat." + A, "محادثات محفوظة"]]);
  const ui = await start({session, language: "ar"});
  assert.equal(ui.chatState(A).id, null);
  assert.equal(session.has("aihub.workspace.chat." + A), false);
  assert.equal(ui.requests.some(request => /^\/v1\/public\/chat\/conversations\//.test(request.url)), false);
  assert.equal(ui.chatState(A).error, null);
  assert.equal(ui.chatState(A).loaded, true);
});

test("malicious source markup remains literal and unsafe publisher URLs are not clickable", async () => {
  const ui = await start(), saved = seed(ui);
  saved.result.items[0].headline = "<img src=x onerror=alert(1)>";
  saved.result.items[0].url = "https://127.0.0.1/private";
  await ui.openAgent(A, false); await ui.settle();
  const content = ui.elements.get("report-content");
  assert.match(content.textContent, /<img src=x onerror=alert\(1\)>/);
  assert.equal(byTag(content, "img").length, 0);
  assert.equal(byTag(content, "a").some(anchor => /127\.0\.0\.1/.test(anchor.href)), false);
});

test("citation labels use stable source-list numbers while preserving internal source IDs", async () => {
  const ui = await start(), saved = seed(ui);
  const secondId = "src_" + "b".repeat(16);
  saved.result.sources.push({id: secondId, title: "Second source", publisher: "Second Publisher", role: "fresh",
    url: "https://second-publisher.example/synthetic", published_at: "2026-10-20T11:30:00Z"});
  saved.result.items[0].source_ids = [secondId, SOURCE_ID];
  await ui.openAgent(A, false); await ui.settle();
  const links = byClass(ui.elements.get("report-content"), "citation-link");
  assert.deepEqual(links.map(link => link.textContent), ["[2] Second Publisher", "[1] Fixture Publisher"]);
  assert.deepEqual(clone(ui.current().report.result.items[0].source_ids), [secondId, SOURCE_ID]);
  await ui.elements.get("tab-pack").click();
  const records = byClass(ui.elements.get("report-content"), "source-record");
  assert.match(records[0].textContent, /^\[1\] Original synthetic evidence/);
  assert.match(records[1].textContent, /^\[2\] Second source/);
  assert.doesNotMatch(ui.elements.get("report-content").textContent, /src_[a-f0-9]{16}/);
});

test("retrying a pinned older PDF preserves the newer head and active job without another report request", async () => {
  const older = report(A, 1, {pdf: {status: "failed"}}), completed = report(A, 1);
  const ui = await start({fetch: (url, request, respond) => {
    if (request.method === "POST" && url === PREFIX + "/reports/" + older.report_id + "/pdf/retry")
      return respond({job: job(A, 1, {stage: "preparing_pdf"})}, 202);
  }});
  const latest = seed(ui, A, 3); ui.server.reports.set(older.report_id, older);
  ui.server.jobs.set(job(A, 1).job_id, {job: job(A, 1, {status: "ready", stage: "ready"}), report: completed});
  await ui.openAgent(A, false); await ui.settle(); ui.acceptJob(A, job(A, 4));
  await ui.openSaved(older.report_id, A); await ui.settle();
  assert.equal(ui.elements.get("pdf-retry").hidden, false);
  await ui.elements.get("pdf-retry").click(); await ui.settle();
  assert.equal(ui.current().report.report_id, older.report_id); assert.equal(ui.current().report.pdf.status, "ready");
  assert.equal(ui.current().latest.report_id, latest.report_id); assert.equal(ui.current().job.generation_seq, 4);
  assert.equal(ui.current().pinned, true); assert.equal(ui.elements.get("pdf-download").hidden, false);
  assert.equal(ui.generations().length, 0);
  assert.equal(ui.requests.filter(request => request.options.method === "POST").length, 1);
});

test("balanced source URL parentheses remain intact in report and chat Markdown citations", async () => {
  const url = "https://fixture.example/news_(briefing)";
  const content = `See [the saved paper](${url}).`;
  const ui = await start({fetch: (path, request, respond) => {
    if (request.method === "POST" && path.endsWith("/messages"))
      return respond(answer(JSON.parse(request.body), {message: {id: "answer_parentheses", role: "assistant", content}}));
  }});
  const saved = seed(ui);
  saved.result.sections[0].body = content;
  saved.result.sources[0].url = url; saved.result.items[0].url = url;
  await ui.openAgent(A, false); await ui.settle(); await ui.elements.get("tab-pack").click();
  const reportAnchor = byTag(ui.elements.get("report-content"), "a").find(a => a.textContent === "the saved paper");
  assert.equal(reportAnchor.href, url);
  assert.equal(reportAnchor.parentNode.textContent, "See the saved paper.");
  const input = await typeChat(ui, "Explain the saved paper.");
  await input.emit("keydown", {key: "Enter"}); await ui.settle();
  const chatAnchor = byTag(ui.elements.get("discussion-panel"), "a").find(a => a.textContent === "the saved paper");
  assert.equal(chatAnchor.href, url);
  assert.equal(chatAnchor.parentNode.textContent, "See the saved paper.");
  assert.equal(chatAnchor.target, "_blank"); assert.equal(chatAnchor.rel, "noopener noreferrer");
});

test("nested and angle-bracket source URLs preserve safe links while markup stays inert", async () => {
  const ui = await start(), saved = seed(ui);
  const nested = "https://fixture.example/news_(briefing_(updated))";
  const bracketed = "https://fixture.example/paper_(appendix)?view=full";
  saved.result.sections[0].body = `**Evidence**: [nested](${nested}) and [angle](<${bracketed}>).\n\n` +
    "<img src=x onerror=alert(1)> [unsafe](javascript:alert(1)) [local](https://127.0.0.1/private) " +
    "[credentials](https://name:secret@fixture.example/private) `literal [link](https://code.example/source)`";
  await ui.openAgent(A, false); await ui.settle(); await ui.elements.get("tab-pack").click();
  const content = ui.elements.get("report-content"), links = byTag(content, "a");
  assert.equal(links.find(a => a.textContent === "nested").href, nested);
  assert.equal(links.find(a => a.textContent === "angle").href, bracketed);
  assert.equal(links.some(a => /javascript:|127\.0\.0\.1|name:secret|code\.example/.test(a.href)), false);
  assert.equal(links.some(a => a.href === "#"), false);
  assert.equal(byTag(content, "img").length, 0);
  assert.match(content.textContent, /<img src=x onerror=alert\(1\)>/);
  assert.equal(byTag(content, "strong")[0].textContent, "Evidence");
  assert.equal(byTag(content, "code")[0].textContent, "literal [link](https://code.example/source)");
});
