# نشر AI HUB 2.0 على GitHub وRender

هذا الدليل يصف **إعدادات المصدر والنشر المستهدف**. حالة النشر الفعلية في [سجل التحقق](VALIDATION_AR.md). استخدم الخدمة والقرص وقاعدة البيانات الحالية.

## البنية

خدمة Python واحدة، وعملية Uvicorn واحدة، و**عاملا مهام داخل التطبيق**. المهام والتقارير والمحادثات في SQLite على القرص الدائم، وPDF في `reports/` بجانبها. لا تحتاج هذه البنية إلى Redis أو عامل Render منفصل.

| الإعداد | القيمة |
|---|---|
| المستودع | [aihub1971-code/AIHUB](https://github.com/aihub1971-code/AIHUB) |
| الخدمة الحالية | `srv-dbb0v3s9v7es73a9o3j0`، اسمها `ai-hub` |
| المنطقة / Runtime | Frankfurt / Python 3.12 |
| Build | `python -m pip install -r requirements.txt` |
| Start | `python -m uvicorn app.main:app --host 0.0.0.0 --port $PORT --workers 1` |
| Health | `/health` |
| القرص | القرص القائم 1 GB عند `/var/data/ai-hub` |
| SQLite | `/var/data/ai-hub/ai-hub.sqlite3` |
| عمال التقارير | `REPORT_JOB_WORKERS=2` |

راجع [توثيق أقراص Render](https://render.com/docs/disks) قبل تغيير النسخ أو القرص؛ الملفات خارجه ليست تخزينًا دائمًا. راجع السعر النهائي والذاكرة في لوحة Render عند تعديل الحوسبة؛ لا تفترض أن سعر استضافة قديم لا يزال ساريًا.

## البيئة المستهدفة

ضع الأسرار في Environment الخاصة بالخدمة، لا في GitHub أو المتصفح:

| المتغير | القيمة أو الدور |
|---|---|
| `OPENAI_API_KEY` | حساب يدعم النموذج وResponses web_search |
| `OPENAI_MODEL_NAME` / `OPENAI_REASONING_EFFORT` | `gpt-6.1-sol` / `low` |
| `APP_USERNAME` / `APP_PASSWORD` | حساب المالك |
| `MAX_REPORTS_PER_DAY` | `50` |
| `DAILY_BUDGET_USD` / `MONTHLY_BUDGET_USD` | `900` / `28000` |
| `REPORT_WORKER_ENABLED` / `REPORT_JOB_WORKERS` | `true` / `2` |
| `SCHEDULER_ENABLED` | `false` |
| `AI_HUB_DATABASE_PATH` | `/var/data/ai-hub/ai-hub.sqlite3` |

السقوف المالية تستوعب الحجز المحافظ للبحث؛ ليست توقعًا للإنفاق ولا اشتراكًا. تبقى ميزانية حساب OpenAI مستقلة. [أسعار النموذج](https://developers.openai.com/api/docs/models/gpt-6.1-sol) و[حجز التطبيق](OPERATIONS_AR.md).

`NEWSDATA_API_KEY` غير مطلوب لمساحة 2.0. يمكن إبقاء القيم القديمة للتوافق مع الإدارة والأرشيف. لا تغيّر إعدادات `MAX_OUTPUT_TOKENS` القديمة حدود البحث الجديد؛ ثوابته في `app/research.py` وتشملها معادلة الحجز.

`render.yaml` يصف الخدمة مباشرة. راجع [مرجع Blueprints](https://render.com/docs/blueprint-spec). تحقق من الأسرار المطلوبة داخل Environment للخدمة القائمة دون كشفها في المخرجات.

## البناء والخطوط

يشغّل Render `app/` من المستودع؛ لا يفك ZIP أثناء البناء. ثبّت `requirements.txt` كما هو. PDF يستخدم `fpdf2` و`uharfbuzz`، مع Noto Sans وNoto Sans Arabic العادي والعريض في `app/assets/fonts/`. ترخيص SIL OFL 1.1 و`OFL.txt` و`SOURCES.json` جزء من التسليم. [تشكيل النص في fpdf2](https://py-pdf.github.io/fpdf2/TextShaping.html).

## تسلسل التحديث

1. احتفظ بنسخة احتياطية من SQLite وPDF الخاصة؛ لا ترفعها إلى المستودع العام.
2. شغّل الاختبارات الاصطناعية وفحوص الواجهة وPDF، ثم تحقق من CI.
3. حدّث متغيرات الخدمة الحالية إلى القيم المستهدفة مع الحفاظ على الأسرار والقرص والمسار.
4. انشر commit الذي اجتاز CI وسجّل بصمته في `docs/VALIDATION_AR.md`.
5. افحص `/health` ثم جلسة عامة وتقريرًا ومراحله ونسخته المحفوظة وPDF والمحادثة بشأنه.

الصحة وحدها لا تختبر رصيد OpenAI أو التواريخ. سجّل النتيجة الحية كما حدثت؛ صفر أخبار موثقة قد يكون صحيحًا لنافذة ضيقة، ولا يبرر إدخال مادة أقدم.

## الاستعادة

العمل المدفوع الذي انقطع بعد الحجز لا يُعاد تلقائيًا؛ تبقى حالته وقيمة الحجز. يمكن استئناف عمل لم يبدأ استدعاءه، وإعادة إخراج PDF من تقرير محفوظ دون بحث جديد. آخر تقرير ناجح يظل متاحًا.

أبقِ Uvicorn بعملية واحدة مع القرص المحلي الحالي. عاملا التقارير داخل العملية يستخدمان ملكية مهام ومهلات تجديد في التخزين؛ لا تضاعفهما بتشغيل خدمات على ملفات SQLite منفصلة.
